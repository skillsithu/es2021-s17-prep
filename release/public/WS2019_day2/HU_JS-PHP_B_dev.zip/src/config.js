export const urlFactory = (route, token) => `http://192.168.56.99/HU_JS-PHP_A/api/v1/${route}${token ? `?token=${token}` : ''}`;

export const getRoute = (route, token) => fetch(urlFactory(route, token)).then(resp => resp.json());
export const postRoute = (route, token, body) => fetch(urlFactory(route, token), {
    method: "POST",
    headers: {
        'Content-Type': 'application/json'
    },
    body: JSON.stringify(body)
}).then(resp => resp.json());