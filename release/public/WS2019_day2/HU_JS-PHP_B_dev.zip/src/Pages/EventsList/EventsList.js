import { useEffect, useState } from "react"
import { EventCard } from "../../Components/EventCard/EventCard"
import { getRoute } from "../../config"

export function EventsList({ goToScreen }) {
    const [events, setEvents] = useState([])

    useEffect(() => {
        getRoute("events").then(({ events }) => setEvents(events))
    }, [])

    return <div>
        {events.map(event => <EventCard event={event} goToScreen={goToScreen} key={event.id} />)}
    </div>
}
