import { useEffect, useMemo, useState } from "react"
import { Ticket } from "../../Components/Ticket/Ticket"
import { getRoute, postRoute } from "../../config"

export function Register({ user, goToScreen }) {
    const [event, setEvent] = useState()
    const [selectedTicket, setSelectedTicket] = useState()
    const [selectedWs, setSelectedWs] = useState([])

    // get the workshops as array
    const workshops = useMemo(() => {
        if (!event) return []

        const ws = []
        // go deep and gather workshops
        event.channels.forEach(c => c.rooms.forEach(r => r.sessions.filter(({ type }) => type === "workshop").forEach(s => ws.push(s))))
        return ws
    }, [event])

    // calculate the prices
    const ticketPrice = selectedTicket ? selectedTicket.cost : 0;
    const wsPrice = useMemo(() => selectedWs.reduce((sum, ws) => sum + ws.cost, 0), [selectedWs])

    // select ws
    const selectWs = (e, ws) => {
        if (e.target.checked) {
            setSelectedWs([...selectedWs, ws])
        } else {
            setSelectedWs(selectedWs.filter(({ id }) => id !== ws.id))
        }
    }

    // on page load get event
    useEffect(() => {
        const parts = window.location.pathname.split('/')
        const organizerSlug = parts[parts.length - 2]
        const eventSlug = parts[parts.length - 1]

        getRoute(`organizers/${organizerSlug}/events/${eventSlug}`).then(data => {
            if (data.message) {
                alert(data.message)
            } else {
                setEvent(data)
            }
        })
    }, [])

    const submit = () => {
        const ticket_id = selectedTicket.id;
        const session_ids = selectedWs.map(({ id }) => id)

        const parts = window.location.pathname.split('/')
        const organizerSlug = parts[parts.length - 2]
        const eventSlug = parts[parts.length - 1]

        postRoute(`organizers/${organizerSlug}/events/${eventSlug}/registration`, user.token, { ticket_id, session_ids }).then(data => {
            if (data.message && data.message === "Registration successful") {
                goToScreen(`/event/${organizerSlug}/${eventSlug}`)
            } else {
                alert(data.message)
            }
        })
    }

    if (!event) return <></>

    return <div>
        <div className="d-flex justify-content-between align-items-center">
            <h2>{event.name}</h2>
        </div>

        <div className="mt-3">
            <div className="row no-gutters">
                {event.tickets.map(ticket => <div key={ticket.id} className="col-4">
                    <Ticket ticket={ticket} selectedTicket={selectedTicket} setSelectedTicket={setSelectedTicket} />
                </div>)}
            </div>
        </div>

        <div className="mt-5">
            <h3 className="h5 mb-3 font-weight-bold">Select additional workshops you want to book</h3>
            {workshops.map(ws => <div className="form-check" key={ws.id}>
                <input className="form-check-input workshop" type="checkbox" value={ws.id} id={`ws${ws.id}`}
                    checked={selectedWs.map(({ id }) => id).includes(ws.id)} onChange={e => selectWs(e, ws)} />
                <label className="form-check-label" htmlFor={`ws${ws.id}`}>
                    {ws.title}
                </label>
            </div>)}
        </div>

        <div className="mt-5 row">
            <div className="col-8"></div>
            <div className="col-4">
                <h3 className="h5 mb-3 font-weight-bold">Checkout</h3>
                <div className="row">
                    <div className="col-9">Event ticket</div>
                    <div className="col-3" id="event-cost">{ticketPrice}.-</div>
                </div>
                <div className="row">
                    <div className="col-9">Additional workshops</div>
                    <div className="col-3" id="additional-cost">{wsPrice}.-</div>
                </div>
                <div className="row border-top">
                    <div className="col-9">Total</div>
                    <div className="col-3" id="total-cost">{ticketPrice + wsPrice}.-</div>
                </div>

                <button className="btn btn-lg btn-outline-secondary mt-5" id="purchase"
                    onClick={() => submit()} disabled={!ticketPrice}>Purchase</button>
            </div>
        </div>
    </div>
}
