import { useEffect, useMemo, useState } from "react"
import { AgendaTable } from "../../Components/AgendaTable/AgendaTable"
import { getRoute } from "../../config"

export function Agenda({ goToScreen, isLoggedIn, user }) {
    const [event, setEvent] = useState()
    const [regs, setRegs] = useState([])

    // select session ids to that user registered
    const selectedIds = useMemo(() => {
        const ev = regs.find(row => row.event.id === event?.id)
        return ev?.session_ids ?? []
    }, [event, regs])

    // register
    const register = () => {
        const parts = window.location.pathname.split('/')
        const organizerSlug = parts[parts.length - 2]
        const eventSlug = parts[parts.length - 1]

        isLoggedIn ? goToScreen(`/register/${organizerSlug}/${eventSlug}`) : goToScreen('/login')
    }

    // select session
    const selectSession = (id) => {
        const parts = window.location.pathname.split('/')
        const organizerSlug = parts[parts.length - 2]
        const eventSlug = parts[parts.length - 1]

        goToScreen(`/session/${organizerSlug}/${eventSlug}/${id}`)
    }

    // Load reg data if logged in
    useEffect(() => {
        if (isLoggedIn) {
            getRoute("registrations", user.token).then(data => {
                if (data.message) {
                    alert(data.message)
                } else {
                    setRegs(data.registrations)
                }
            })
        }
    }, [isLoggedIn, user])

    // Load event data
    useEffect(() => {
        const parts = window.location.pathname.split('/')
        const organizerSlug = parts[parts.length - 2]
        const eventSlug = parts[parts.length - 1]

        getRoute(`organizers/${organizerSlug}/events/${eventSlug}`).then(data => {
            if (data.message) {
                alert(data.message)
            } else {
                setEvent(data)
            }
        })
    }, [])

    if (!event) return <></>

    return <div>
        <div className="d-flex justify-content-between align-items-center">
            <h2>{event.name}</h2>
            <button className="btn btn-outline-secondary" id="register" onClick={register}>Register for this event</button>
        </div>

        <div className="mt-3">
            <AgendaTable event={event} selectSession={selectSession} isLoggedIn={isLoggedIn} selectedIds={selectedIds} />
        </div>
    </div>
}
