import { useState } from "react"
import { postRoute } from "../../config";

export function Login({ login }) {
    const [lastname, setLastname] = useState("");
    const [code, setCode] = useState("");
    const [error, setError] = useState("");

    const submit = (e) => {
        e.preventDefault()
        e.stopPropagation()

        postRoute("login", "", { lastname, registration_code: code }).then(data => {
            if (data.message) {
                setError("Lastname or registration code not correct")
            } else {
                setLastname("")
                setCode("")
                setError("")
                login(data)
                // this should be inside this promise to trigger history back in next render circle
                Promise.resolve().then(() => window.history.back())
            }
        })
    }

    return <div>
        <h2 className="mb-3">Login</h2>
        {error && <div className="alert alert-danger my-4" role="alert">
            {error}
        </div>}
        <form onSubmit={submit}>
            <div className="form-group">
                <label htmlFor="lastname">Lastname</label>
                <input type="text" className="form-control" id="lastname" placeholder="Lastname"
                    value={lastname} onChange={e => setLastname(e.target.value)} />
            </div>
            <div className="form-group">
                <label htmlFor="registration_code">Registration Code</label>
                <input type="text" className="form-control" id="registration_code" placeholder="Code"
                    value={code} onChange={e => setCode(e.target.value)} />
            </div>
            <button type="submit" className="btn btn-secondary" id="login">Login</button>
        </form>
    </div>
}