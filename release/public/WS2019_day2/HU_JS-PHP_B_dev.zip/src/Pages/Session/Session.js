import { useEffect, useState } from "react"
import { getRoute } from "../../config"

export function Session() {
    const [event, setEvent] = useState()
    const [session, setSession] = useState()

    useEffect(() => {
        const parts = window.location.pathname.split('/')
        const organizerSlug = parts[parts.length - 3]
        const eventSlug = parts[parts.length - 2]
        const sessionId = parseInt(parts[parts.length - 1], 10)

        getRoute(`organizers/${organizerSlug}/events/${eventSlug}`).then(data => {
            if (data.message) {
                alert(data.message)
            } else {
                let session;
                data.channels.forEach(c => c.rooms.forEach(r => r.sessions.forEach((s) => { if (s.id === sessionId) session = s })))
                setSession(session)
                setEvent(data)
            }
        })
    }, [])

    if (!event) return <></>

    if (!session) return <p>Session not found</p>

    return <div>
        <h2>{session.title} - {session.type}</h2>
        <p>{session.description}</p>
        <div className="row">
            <div className="col-3 text-brown">Speaker</div>
            <div className="col-3">{session.speaker}</div>
        </div>
        <div className="row">
            <div className="col-3 text-brown">Start</div>
            <div className="col-3">{session.start}</div>
        </div>
        <div className="row">
            <div className="col-3 text-brown">End</div>
            <div className="col-3">{session.end}</div>
        </div>
        {session.cost && <div className="row">
            <div className="col-3 text-brown">Cost</div>
            <div className="col-3">{session.cost}.-</div>
        </div>}
    </div>
}
