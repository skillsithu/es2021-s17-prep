export function Footer() {
    return <footer className="bg-dark text-white p-3 mt-3 text-center">
        <small>&copy; Copyright 2021 - All rights reserved.</small>
    </footer>
}
