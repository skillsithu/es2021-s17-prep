export function Main({ children }) {
    return <main className="flex-fill mt-5 container">{ children }</main>
}
