import { postRoute } from "../../config"

export function Header({ goToScreen, logout, user, isLoggedIn }) {
    const _logout = () => {
        postRoute("logout", user.token).then(() => logout())
    }

    return <header className="sticky-top shadow-sm">
        <nav className="navbar navbar-light bg-light">
            <div className="container-fluid d-flex justify-content-between align-items-center">
                <div onClick={() => goToScreen("/")} role="button">
                    <h1 className="navbar-brand m-0">Event Booking Platform</h1>
                </div>

                {!isLoggedIn && <div>
                    <button className="btn btn-outline-secondary login-btn" onClick={() => goToScreen("/login")}>Login</button>
                </div>}

                {isLoggedIn && <div className="d-flex justify-content-center align-items-center">
                    <span className="mr-3">{ user.username }</span>
                    <button className="btn btn-outline-secondary text-dark logout-btn" onClick={() => _logout()}>Logout</button>
                </div>}
            </div>
        </nav>
    </header>
}
