import { useCallback, useEffect, useMemo, useState } from 'react';
import { Footer } from './Skeleton/Footer/Footer';
import { Header } from './Skeleton/Header/Header';
import { Main } from './Skeleton/Main/Main';
import { Agenda } from './Pages/Agenda/Agenda';
import { EventsList } from './Pages/EventsList/EventsList';
import { Login } from './Pages/Login/Login';
import { Register } from './Pages/Register/Register';
import { Session } from './Pages/Session/Session';

function App() {
  const [screen, setScreen] = useState();
  const [user, setUser] = useState();

  // on page onload, set user from localstorage and screen from url
  useEffect(() => {
    if (localStorage.getItem("user")) {
      setUser(JSON.parse(localStorage.getItem("user")))
    }

    const setCurrentScreen = () => {
      const basePath = process.env.PUBLIC_URL.replace(window.location.origin, "")
      const parts = window.location.pathname.replace(basePath, "").split('/');
      setScreen(parts[1])
    }

    setCurrentScreen()

    window.addEventListener("popstate", setCurrentScreen)

    return () => window.removeEventListener("popstate", setCurrentScreen)
  }, [])

  // handle login
  const login = (user) => {
    setUser(user)
    localStorage.setItem("user", JSON.stringify(user))
  }

  // handle logout
  const logout = () => {
    setUser(undefined)
    localStorage.removeItem("user")
    goToScreen("/login")
  }

  const isLoggedIn = useMemo(() => !!user, [user])

  // routing
  const goToScreen = useCallback((route) => {
    const newScreen = route.split("/")[1];

    if (screen !== newScreen) {
      setScreen(newScreen);
      window.history.pushState("", "", `${process.env.PUBLIC_URL}${route}`);
    }
  }, [screen])

  // routing
  const Page = useMemo(() => {
    const Noop = () => <></>;

    switch (screen) {
      case undefined:
        return Noop
      case "event":
        return (props) => <Agenda {...props} />
      case "session":
        return (props) => <Session {...props} />
      case "register":
        if (isLoggedIn) {
          return (props) => <Register {...props} />
        } else {
          goToScreen("/login")
          return Noop
        }
      case "login":
        return (props) => <Login {...props} />
      default:
        break;
    }

    return (props) => <EventsList {...props} />
  }, [screen, isLoggedIn, goToScreen])

  return (
    <>
      <Header goToScreen={goToScreen} logout={logout} isLoggedIn={isLoggedIn} user={user} />
      <Main>
        <Page login={login} logout={logout} isLoggedIn={isLoggedIn} user={user} goToScreen={goToScreen} />
      </Main>
      <Footer />
    </>
  );
}

export default App;
