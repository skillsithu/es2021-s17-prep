export function EventCard({ event, goToScreen }) {
    return <div className="border p-3 mb-4 bg-light card-hover event" onClick={() => goToScreen(`/event/${event.organizer.slug}/${event.slug}`)} role="button">
        <h2 className="m-0 mb-2">{event.name}</h2>
        <p className="m-0">{event.organizer.name}, {event.date}</p>
    </div>
}
