import { useMemo } from "react"

export function Ticket({ ticket, selectedTicket, setSelectedTicket }) {
    const extra = useMemo(() => {
        if (!ticket.available) {
            return "unavailable";
        } else {
            return ticket.description
        }
    }, [ticket])

    const select = () => {
        if (ticket.available) {
            setSelectedTicket(ticket)
        }
    }

    const classes = ticket.available ? "card-hover bg-white cursor-pointer" : "bg-light disabled"

    return <div className={`p-3 border ticket row no-gutters d-flex align-items-center mx-2 ${classes}`} onClick={select}>
        <div className="col-auto mr-3">
            <input type="radio" name="ticket" checked={selectedTicket === ticket} onChange={select} id={`ticket${ticket.id}`} />
        </div>
        <label className="col d-flex flex-column justify-content-center mb-0" htmlFor={`ticket${ticket.id}`}>
            <h3 className="h4 m-0">{ticket.name} {ticket.cost}.-</h3>
            {extra && <p className="m-0 mt-2">{extra}</p>}
        </label>
    </div>
}