export function AgendaTable({ event, selectSession, isLoggedIn, selectedIds }) {
    return <div>
        <div className="row no-gutters clock">
            <div className="col-4"></div>
            <div className="col-2">9:00</div>
            <div className="col-2">11:00</div>
            <div className="col-2">13:00</div>
            <div className="col-2">15:00</div>
        </div>
        {event.channels.map(channel => <div className="row border no-gutters" key={channel.id}>
            <div className="col-2 border-right p-2 channel">
                {channel.name}
            </div>
            <div className="col-10">
                {channel.rooms.map(room => <div className="row no-gutters" key={room.id}>
                    <div className="col-2 border-right p-2 room">{room.name}</div>
                    <div className="col-10 d-flex">
                        {room.sessions.map(session => {
                            const selected = isLoggedIn && (session.type === 'talk' || selectedIds.includes(session.id))
                            return <div className={`p-2 m-1 agenda-item session ${selected ? 'registered' : ''}`} key={session.id}
                                onClick={() => selectSession(session.id)} role="button">{session.title}</div>
                        })}
                    </div>
                </div>)}
            </div>
        </div>)}
    </div>
}
